package com.app.l_pesa.login.model

import com.app.l_pesa.common.CommonStatusModel

class ResEmailVerification(val status: CommonStatusModel)