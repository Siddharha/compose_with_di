package com.app.l_pesa.profile.inter

interface ICallBackContactInfo {

    fun onSuccessContactInfo()
    fun onFailureContactInfo(message: String)
    fun onSessionTimeOut(message: String)
}