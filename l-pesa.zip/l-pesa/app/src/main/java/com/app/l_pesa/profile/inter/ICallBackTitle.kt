package com.app.l_pesa.profile.inter

interface ICallBackTitle {

    fun onChangeTitle(s: String)
}