package com.app.l_pesa.registration.model

import com.app.l_pesa.common.CommonStatusModel

data class ResRegistrationThree(val status: CommonStatusModel)