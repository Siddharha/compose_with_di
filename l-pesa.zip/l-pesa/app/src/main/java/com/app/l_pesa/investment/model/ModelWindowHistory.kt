package com.app.l_pesa.investment.model

data class ModelWindowHistory(val name: String, val status:Boolean)