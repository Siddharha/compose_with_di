package com.app.l_pesa.profile.inter

interface ICallBackEmpInfo {

    fun onSuccessEmpInfo()
    fun onFailureEmpInfo(message: String)
    fun onSessionTimeOut(message: String)
}