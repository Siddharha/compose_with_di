package com.app.l_pesa.profile.model

import com.app.l_pesa.common.CommonStatusModel


data class ResPersonalInfo(val status: CommonStatusModel)