package com.app.l_pesa.loanplan.inter

interface ICallBackDescription {

    fun onSelectDescription(s: String)
}