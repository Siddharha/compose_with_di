package com.app.l_pesa.loanplan.model

import com.app.l_pesa.common.CommonStatusModel

class ResLoanApply(val status: CommonStatusModel)