package com.app.l_pesa.settings.inter

interface ICallBackCloseAccount {

    fun onSuccessCloseAccount(message: String)
    fun onErrorCloseAccount(message: String)
}