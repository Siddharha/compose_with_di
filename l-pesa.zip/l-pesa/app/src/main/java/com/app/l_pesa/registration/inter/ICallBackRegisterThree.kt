package com.app.l_pesa.registration.inter

interface ICallBackRegisterThree {

    fun onSuccessRegistrationThree()
    fun onErrorRegistrationThree(jsonMessage: String)
}