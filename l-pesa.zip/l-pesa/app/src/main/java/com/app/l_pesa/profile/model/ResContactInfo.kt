package com.app.l_pesa.profile.model

import com.app.l_pesa.common.CommonStatusModel

data class ResContactInfo(val status: CommonStatusModel)