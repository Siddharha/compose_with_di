package com.app.l_pesa.profile.model

data class ModelWindowPopUp(val icon:Int, val name: String)