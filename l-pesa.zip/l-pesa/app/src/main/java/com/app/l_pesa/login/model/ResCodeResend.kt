package com.app.l_pesa.login.model

import com.app.l_pesa.common.CommonStatusModel

class ResCodeResend (val status: CommonStatusModel)