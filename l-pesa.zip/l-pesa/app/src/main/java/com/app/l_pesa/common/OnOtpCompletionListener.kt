package com.app.l_pesa.common

interface OnOtpCompletionListener {

    fun onOtpCompleted(otp: String)
}
