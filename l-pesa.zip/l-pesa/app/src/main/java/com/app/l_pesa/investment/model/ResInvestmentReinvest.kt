package com.app.l_pesa.investment.model

import com.app.l_pesa.common.CommonStatusModel

data class ResInvestmentReinvest(val status: CommonStatusModel)