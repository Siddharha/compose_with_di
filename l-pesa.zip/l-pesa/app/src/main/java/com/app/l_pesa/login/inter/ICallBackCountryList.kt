package com.app.l_pesa.login.inter

import com.app.l_pesa.splash.model.ResModelCountryList


/**
 * Created by Intellij Amiya on 30-01-2019.
 * A good programmer is someone who looks both ways before crossing a One-way street.
 * Kindly follow https://source.android.com/setup/code-style
 */

interface ICallBackCountryList {
    fun onClickCountry(resModelCountryList: ResModelCountryList)

}