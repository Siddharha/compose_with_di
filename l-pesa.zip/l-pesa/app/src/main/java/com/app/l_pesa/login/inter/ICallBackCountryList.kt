package com.app.l_pesa.login.inter

import com.app.l_pesa.splash.model.ResModelCountryList


interface ICallBackCountryList {
    fun onClickCountry(resModelCountryList: ResModelCountryList)

}