package com.app.l_pesa.logout.model

import com.app.l_pesa.common.CommonStatusModel

data class ResLogout(val status: CommonStatusModel)