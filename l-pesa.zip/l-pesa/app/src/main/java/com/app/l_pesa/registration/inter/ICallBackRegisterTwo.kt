package com.app.l_pesa.registration.inter

interface ICallBackRegisterTwo {

    fun onSuccessRegistrationTwo()
    fun onErrorRegistrationTwo(jsonMessage: String)
}