package com.app.l_pesa.common


data class CommonStatusModel(val statusCode: String, val isSuccess: Boolean, val message: String)