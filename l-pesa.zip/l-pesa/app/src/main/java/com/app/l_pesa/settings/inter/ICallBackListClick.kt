package com.app.l_pesa.settings.inter


interface ICallBackListClick {

    fun onClickListItem(position: Int?)
}