package com.app.l_pesa.settings.inter


/**
 * Created by Intellij Amiya on 04-02-2019.
 * A good programmer is someone who looks both ways before crossing a One-way street.
 * Kindly follow https://source.android.com/setup/code-style
 */
interface ICallBackListClick {

    fun onClickListItem(position: Int?)
}