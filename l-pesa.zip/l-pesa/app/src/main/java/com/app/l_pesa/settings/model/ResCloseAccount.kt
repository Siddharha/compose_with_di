package com.app.l_pesa.settings.model

import com.app.l_pesa.common.CommonStatusModel

class ResCloseAccount(val status:CommonStatusModel)