package com.app.l_pesa.profile.inter

interface ICallBackId {

    fun onClickIdType(position: Int, type: String)
}