package com.app.l_pesa.pin.model

import com.app.l_pesa.common.CommonStatusModel


data class ResChangeLoginPin(val status: CommonStatusModel)