package com.app.l_pesa.pin.model

import com.app.l_pesa.common.CommonStatusModel


/**
 * Created by Intellij Amiya on 05-02-2019.
 * A good programmer is someone who looks both ways before crossing a One-way street.
 * Kindly follow https://source.android.com/setup/code-style
 */

data class ResChangeLoginPin(val status: CommonStatusModel)