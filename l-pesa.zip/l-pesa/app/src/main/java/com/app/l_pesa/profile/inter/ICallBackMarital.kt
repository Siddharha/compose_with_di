package com.app.l_pesa.profile.inter

interface ICallBackMarital {

    fun onChangeMarital(s: String)
}