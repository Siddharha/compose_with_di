package com.app.l_pesa.settings.model



data class SettingsItem (val name: String?, val image: Int?)