package com.app.l_pesa.settings.model


/**
 * Created by Intellij Amiya on 04-02-2019.
 * A good programmer is someone who looks both ways before crossing a One-way street.
 * Kindly follow https://source.android.com/setup/code-style
 */

data class SettingsItem (val name: String?, val image: Int?)