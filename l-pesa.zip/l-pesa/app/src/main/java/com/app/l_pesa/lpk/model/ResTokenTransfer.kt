package com.app.l_pesa.lpk.model

import com.app.l_pesa.common.CommonStatusModel

class ResTokenTransfer(val status: CommonStatusModel)