package com.app.l_pesa.loanHistory.model

import com.app.l_pesa.common.CommonStatusModel

class ResLoanCancel(val status: CommonStatusModel)