package com.app.l_pesa.common;

public interface OnOtpCompletionListener {

    void onOtpCompleted(String otp);
}
